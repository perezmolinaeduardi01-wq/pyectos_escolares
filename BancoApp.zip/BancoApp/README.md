﻿#  Sistema Bancario — Árbol BST en Memoria Externa + XML

Aplicación de escritorio en **Java Swing** para la gestión de cuentas bancarias,
sin ningún motor de base de datos. Toda la persistencia se realiza mediante:

-  **Árbol Binario de Búsqueda (BST)** almacenado en un **archivo binario** (memoria externa) con `RandomAccessFile`.
-  **Archivo XML** para exportar / importar las cuentas de forma portable.

---


##  Características

- Alta, baja, modificación y consulta de cuentas bancarias (CRUD).
- Depósitos y retiros con validación de saldo.
- Búsqueda eficiente por número de cuenta en **O(log n)** promedio.
- Recorrido **in-orden** del árbol → cuentas ordenadas por número.
- Persistencia **sin base de datos**: el árbol se guarda en un archivo binario.
- Exportación / importación **XML**.
- Interfaz gráfica con pestañas (Swing).
- Estadísticas en tiempo real (total de cuentas y saldo total).

---

##  Arquitectura

```
┌─────────────────────┐
│   Swing GUI         │  PanelGestion · PanelOperaciones · PanelBusqueda
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Banco (JFrame)    │  Fachada: agrega, busca, elimina, actualiza
└──────────┬──────────┘
           │
           ├──────────────► CuentaXMLManager  ──►  data/cuentas.xml
           │
           ▼
┌─────────────────────┐
│ ArbolBinarioBusqueda│  RandomAccessFile
└──────────┬──────────┘
           ▼
   data/arbol_cuentas.dat
```

---

##  Estructura del proyecto

```
BancoApp/
├── src/banco/
│   ├── modelo/
│   │   └── CuentaBancaria.java
│   ├── excepciones/
│   │   └── CuentaNoEncontradaException.java
│   ├── estructuras/
│   │   └── ArbolBinarioBusqueda.java
│   ├── persistencia/
│   │   └── CuentaXMLManager.java
│   ├── vista/
│   │   ├── PanelGestion.java
│   │   ├── PanelOperaciones.java
│   │   └── PanelBusqueda.java
│   └── Banco.java
├── data/
│   ├── arbol_cuentas.dat     ← se crea automáticamente
│   └── cuentas.xml           ← se crea al exportar
└── README.md
```

---

##  Requisitos

- **JDK 11** o superior (probado con 17).
- Sin dependencias externas (solo la librería estándar de Java).

---


### . `data/cuentas.xml` — Exportación XML

```xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<cuentas total="2">
    <cuenta numero="001">
        <titular>Ana Torres</titular>
        <saldo>1500.00</saldo>
    </cuenta>
    <cuenta numero="002">
        <titular>Luis Gómez</titular>
        <saldo>500.00</saldo>
    </cuenta>
</cuentas>
```

---

##  Uso de la aplicación

### Pestaña **Gestión de Cuentas**
| Botón | Acción |
|---|---|
| Agregar Cuenta | Inserta un nuevo nodo en el árbol BST |
| Eliminar Cuenta Seleccionada | Elimina el nodo correspondiente |
| Actualizar Lista | Refresca la tabla desde el árbol (in-orden) |
| Exportar a XML | Vuelca el árbol a `data/cuentas.xml` |
| Importar desde XML | Inserta en el árbol las cuentas del XML que no existan |
| Vaciar Todo | Borra todos los nodos del archivo binario |

### Pestaña **Operaciones Bancarias**
- **Depositar** → suma al saldo y actualiza el nodo.
- **Retirar** → resta si hay saldo suficiente, si no muestra error.

### Pestaña **Buscar Cuenta (BST)**
- Búsqueda binaria por número de cuenta.
- Botón para mostrar el **recorrido in-orden** (todas las cuentas ordenadas).

---

##  Detalles de implementación

### Árbol Binario de Búsqueda en memoria externa

- **Clave de ordenamiento:** `numeroCuenta` (comparación lexicográfica).
- **Nodos:** cada nodo vive en un bloque fijo dentro del archivo binario; los
  punteros `idIzq` / `idDer` son **índices lógicos**, no direcciones de memoria.
- **Eliminación con dos hijos:** se usa el **sucesor in-orden** (mínimo del
  subárbol derecho).
- **Complejidad promedio:** `O(log n)` para búsqueda / inserción / eliminación
  (se degrada a `O(n)` si el árbol queda degenerado).
- Los datos nunca se cargan completos en memoria: cada operación lee y escribe
  sólo los nodos necesarios.

### Recorrido in-orden

Devuelve las cuentas **ordenadas ascendentemente por número**, recorriendo
recursivamente el subárbol izquierdo, la raíz y el subárbol derecho.

### XML

- Escritura con `Transformer` + `DOMSource` (indentado a 4 espacios).
- Lectura con `DocumentBuilderFactory` estándar.
- La importación **no sobrescribe** cuentas existentes: sólo añade las nuevas.

---

##  Posibles mejoras

- Balanceo automático (**AVL** o **Rojo-Negro**) para garantizar `O(log n)`.
- Índice secundario por titular.
- Cifrado del archivo binario (AES).
- Validación del XML con un XSD.
- Exportación a JSON / CSV además de XML.
- Multi-hilo con acceso concurrente al árbol.

---

##  Licencia

Proyecto académico de libre uso.
ive en un bloque fijo dentro del archivo binario; los
  punteros `idIzq` / `idDer` son **índices lógicos**, no direcciones de memoria.
- **Eliminación con dos hijos:** se usa el **sucesor in-orden** (mínimo del
  subárbol derecho).
- **Complejidad promedio:** `O(log n)` para búsqueda / inserción / eliminación
  (se degrada a `O(n)` si el árbol queda degenerado).
- Los datos nunca se cargan completos en memoria: cada operación lee y escribe
  sólo los nodos necesarios.

### Recorrido in-orden

Devuelve las cuentas **ordenadas ascendentemente por número**, recorriendo
recursivamente el subárbol izquierdo, la raíz y el subárbol derecho.

### XML

- Escritura con `Transformer` + `DOMSource` (indentado a 4 espacios).
- Lectura con `DocumentBuilderFactory` estándar.
- La importación **no sobrescribe** cuentas existentes: sólo añade las nuevas.

---

##  Posibles mejoras

- Índice secundario por titular.
- Cifrado del archivo binario (AES).
- Validación del XML con un XSD.
- Exportación a JSON / CSV además de XML.
- Multi-hilo con acceso concurrente al árbol.

---

##  Licencia

Proyecto académico de libre uso.
urrente al árbol.

---

##  Licencia

Proyecto académico de libre uso.
erFactory` estándar.
- La importación **no sobrescribe** cuentas existentes: sólo añade las nuevas.

---

##  Posibles mejoras

- Balanceo automático (**AVL** o **Rojo-Negro**) para garantizar `O(log n)`.
- Índice secundario por titular.
- Cifrado del archivo binario (AES).
- Validación del XML con un XSD.
- Exportación a JSON / CSV además de XML.
- Multi-hilo con acceso concurrente al árbol.

---

##  Licencia

Proyecto académico de libre uso.
