﻿package banco.persistencia;

import banco.modelo.CuentaBancaria;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CuentaXMLManager {

    private static final String RUTA_XML = "data/cuentas.xml";

    /** Exporta la lista de cuentas al archivo XML. */
    public static void exportar(List<CuentaBancaria> cuentas) throws Exception {
        File dir = new File("data");
        if (!dir.exists()) dir.mkdirs();

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();

        Element raiz = doc.createElement("cuentas");
        raiz.setAttribute("total", String.valueOf(cuentas.size()));
        doc.appendChild(raiz);

        for (CuentaBancaria c : cuentas) {
            Element e = doc.createElement("cuenta");
            e.setAttribute("numero", c.getNumeroCuenta());

            Element titular = doc.createElement("titular");
            titular.setTextContent(c.getTitular());
            e.appendChild(titular);

            Element saldo = doc.createElement("saldo");
            saldo.setTextContent(String.format("%.2f", c.getSaldo()));
            e.appendChild(saldo);

            raiz.appendChild(e);
        }

        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        t.transform(new DOMSource(doc), new StreamResult(new File(RUTA_XML)));
    }

    /** Importa cuentas desde el XML (si existe). */
    public static List<CuentaBancaria> importar() throws Exception {
        List<CuentaBancaria> lista = new ArrayList<>();
        File f = new File(RUTA_XML);
        if (!f.exists()) return lista;

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        Document doc = dbf.newDocumentBuilder().parse(f);
        doc.getDocumentElement().normalize();

        NodeList nodos = doc.getElementsByTagName("cuenta");
        for (int i = 0; i < nodos.getLength(); i++) {
            Element e = (Element) nodos.item(i);
            String numero  = e.getAttribute("numero");
            String titular = e.getElementsByTagName("titular").item(0).getTextContent();
            double saldo   = Double.parseDouble(
                    e.getElementsByTagName("saldo").item(0).getTextContent());
            lista.add(new CuentaBancaria(titular, numero, saldo));
        }
        return lista;
    }

    public static String getRuta() { return RUTA_XML; }
}
