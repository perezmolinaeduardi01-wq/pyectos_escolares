﻿package banco.estructuras;

import banco.modelo.CuentaBancaria;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * Árbol Binario de Búsqueda almacenado en archivo binario (memoria externa).
 * Cada nodo ocupa un bloque fijo de bytes, permitiendo acceso aleatorio.
 */
public class ArbolBinarioBusqueda {

    private static final int TAM_NODO = 257;
    private static final int MAX_NUM  = 20;   // chars numeroCuenta
    private static final int MAX_TIT  = 100;  // chars titular
    private static final String RUTA  = "data/arbol_cuentas.dat";

    private RandomAccessFile archivo;
    private int raizId = -1;
    private int siguienteId = 0;

    public ArbolBinarioBusqueda() {
        try {
            File dir = new File("data");
            if (!dir.exists()) dir.mkdirs();

            File f = new File(RUTA);
            boolean nuevo = !f.exists();
            archivo = new RandomAccessFile(f, "rw");

            if (!nuevo && archivo.length() >= 8) {
                archivo.seek(0);
                raizId = archivo.readInt();
                siguienteId = archivo.readInt();
            } else {
                archivo.setLength(0);
                archivo.seek(0);
                archivo.writeInt(raizId);
                archivo.writeInt(siguienteId);
            }
        } catch (IOException e) {
            System.err.println("Error al abrir el árbol: " + e.getMessage());
        }
    }

    //API pública 

    public void insertar(CuentaBancaria cuenta) {
        try {
            raizId = insertarRec(raizId, cuenta);
            guardarCabecera();
        } catch (IOException e) {
            System.err.println("Error al insertar: " + e.getMessage());
        }
    }

    public CuentaBancaria buscar(String numeroCuenta) {
        try {
            return buscarRec(raizId, numeroCuenta);
        } catch (IOException e) {
            System.err.println("Error al buscar: " + e.getMessage());
            return null;
        }
    }

    public boolean eliminar(String numeroCuenta) {
        try {
            boolean[] eliminado = {false};
            raizId = eliminarRec(raizId, numeroCuenta, eliminado);
            guardarCabecera();
            return eliminado[0];
        } catch (IOException e) {
            System.err.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }

    public List<CuentaBancaria> inOrden() {
        List<CuentaBancaria> lista = new ArrayList<>();
        try {
            inOrdenRec(raizId, lista);
        } catch (IOException e) {
            System.err.println("Error en recorrido: " + e.getMessage());
        }
        return lista;
    }

    public void vaciar() {
        try {
            archivo.setLength(0);
            archivo.seek(0);
            archivo.writeInt(-1);
            archivo.writeInt(0);
            raizId = -1;
            siguienteId = 0;
        } catch (IOException e) {
            System.err.println("Error al vaciar: " + e.getMessage());
        }
    }

    public void reconstruir(List<CuentaBancaria> cuentas) {
        vaciar();
        for (CuentaBancaria c : cuentas) insertar(c);
    }

    public void cerrar() {
        try { if (archivo != null) archivo.close(); } catch (IOException ignored) {}
    }

    // ---------------- Recursión ----------------

    private int insertarRec(int idNodo, CuentaBancaria cuenta) throws IOException {
        if (idNodo == -1) return crearNodo(cuenta);

        Nodo n = leerNodo(idNodo);
        int cmp = cuenta.getNumeroCuenta().compareTo(n.numeroCuenta);

        if (cmp < 0) {
            n.idIzq = insertarRec(n.idIzq, cuenta);
        } else if (cmp > 0) {
            n.idDer = insertarRec(n.idDer, cuenta);
        } else {
            // Ya existe -> actualiza
            n.titular = cuenta.getTitular();
            n.saldo   = cuenta.getSaldo();
        }
        escribirNodo(idNodo, n);
        return idNodo;
    }

    private CuentaBancaria buscarRec(int idNodo, String numero) throws IOException {
        if (idNodo == -1) return null;
        Nodo n = leerNodo(idNodo);
        int cmp = numero.compareTo(n.numeroCuenta);
        if (cmp == 0) return new CuentaBancaria(n.titular, n.numeroCuenta, n.saldo);
        return cmp < 0 ? buscarRec(n.idIzq, numero) : buscarRec(n.idDer, numero);
    }

    private int eliminarRec(int idNodo, String numero, boolean[] eliminado) throws IOException {
        if (idNodo == -1) return -1;
        Nodo n = leerNodo(idNodo);
        int cmp = numero.compareTo(n.numeroCuenta);

        if (cmp < 0) {
            n.idIzq = eliminarRec(n.idIzq, numero, eliminado);
            escribirNodo(idNodo, n);
            return idNodo;
        } else if (cmp > 0) {
            n.idDer = eliminarRec(n.idDer, numero, eliminado);
            escribirNodo(idNodo, n);
            return idNodo;
        }

        // Encontrado
        eliminado[0] = true;

        if (n.idIzq == -1 && n.idDer == -1) return -1;   // hoja
        if (n.idIzq == -1) return n.idDer;               // sólo hijo derecho
        if (n.idDer == -1) return n.idIzq;               // sólo hijo izquierdo

        // Dos hijos: sucesor(mínimo del subárbol derecho)
        Nodo sucesor = minimo(n.idDer);
        n.numeroCuenta = sucesor.numeroCuenta;
        n.titular      = sucesor.titular;
        n.saldo        = sucesor.saldo;
        n.idDer        = eliminarRec(n.idDer, sucesor.numeroCuenta, new boolean[1]);
        escribirNodo(idNodo, n);
        return idNodo;
    }

    private Nodo minimo(int idNodo) throws IOException {
        Nodo n = leerNodo(idNodo);
        while (n.idIzq != -1) n = leerNodo(n.idIzq);
        return n;
    }

    private void inOrdenRec(int idNodo, List<CuentaBancaria> lista) throws IOException {
        if (idNodo == -1) return;
        Nodo n = leerNodo(idNodo);
        inOrdenRec(n.idIzq, lista);
        lista.add(new CuentaBancaria(n.titular, n.numeroCuenta, n.saldo));
        inOrdenRec(n.idDer, lista);
    }

    //IO de nodos

    private int crearNodo(CuentaBancaria c) throws IOException {
        int id = siguienteId++;
        Nodo n = new Nodo(id, -1, -1, c.getNumeroCuenta(), c.getTitular(), c.getSaldo());
        escribirNodo(id, n);
        return id;
    }

    private Nodo leerNodo(int id) throws IOException {
        archivo.seek(8L + (long) id * TAM_NODO);
        Nodo n = new Nodo();
        n.id           = archivo.readInt();
        n.idIzq        = archivo.readInt();
        n.idDer        = archivo.readInt();
        n.numeroCuenta = leerStringFijo(MAX_NUM);
        n.titular      = leerStringFijo(MAX_TIT);
        n.saldo        = archivo.readDouble();
        archivo.readBoolean(); // ocupado
        return n;
    }

    private void escribirNodo(int id, Nodo n) throws IOException {
        archivo.seek(8L + (long) id * TAM_NODO);
        archivo.writeInt(n.id);
        archivo.writeInt(n.idIzq);
        archivo.writeInt(n.idDer);
        escribirStringFijo(n.numeroCuenta, MAX_NUM);
        escribirStringFijo(n.titular, MAX_TIT);
        archivo.writeDouble(n.saldo);
        archivo.writeBoolean(true);
    }

    private void guardarCabecera() throws IOException {
        archivo.seek(0);
        archivo.writeInt(raizId);
        archivo.writeInt(siguienteId);
    }

    private void escribirStringFijo(String s, int chars) throws IOException {
        StringBuilder sb = new StringBuilder(s == null ? "" : s);
        sb.setLength(chars);
        for (int i = 0; i < chars; i++) archivo.writeChar(sb.charAt(i));
    }

    private String leerStringFijo(int chars) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < chars; i++) sb.append(archivo.readChar());
        return sb.toString().trim();
    }

    //Nodo interno

    private static class Nodo {
        int id, idIzq, idDer;
        String numeroCuenta, titular;
        double saldo;

        Nodo() {}
        Nodo(int id, int i, int d, String nc, String t, double s) {
            this.id = id; this.idIzq = i; this.idDer = d;
            this.numeroCuenta = nc; this.titular = t; this.saldo = s;
        }
    }
}
