﻿package banco.vista;

import banco.Banco;
import banco.modelo.CuentaBancaria;

import javax.swing.*;
import java.awt.*;

public class PanelBusqueda extends JPanel {

    private final Banco banco;
    private final JTextField txtBuscar = new JTextField(15);
    private final JTextArea txtResultado = new JTextArea(12, 50);

    public PanelBusqueda(Banco banco) {
        this.banco = banco;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Buscar por Número de Cuenta (BST):"), gbc);
        gbc.gridx = 1; add(txtBuscar, gbc);

        JButton btnBuscar  = new JButton("Buscar en Árbol");
        JButton btnInOrden = new JButton("Recorrido in-orden (ordenado)");
        btnBuscar.addActionListener(e -> buscar());
        btnInOrden.addActionListener(e -> inOrden());

        txtResultado.setEditable(false);
        txtResultado.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        add(btnBuscar, gbc);
        gbc.gridy = 2; add(btnInOrden, gbc);
        gbc.gridy = 3;
        add(new JScrollPane(txtResultado), gbc);
    }

    private void buscar() {
        CuentaBancaria c = banco.buscar(txtBuscar.getText().trim());
        if (c == null) {
            txtResultado.setText("Cuenta no encontrada.");
        } else {
            txtResultado.setText("Cuenta encontrada (vía BST en archivo):\n\n");
            txtResultado.append("Titular : " + c.getTitular() + "\n");
            txtResultado.append("Número  : " + c.getNumeroCuenta() + "\n");
            txtResultado.append(String.format("Saldo   : $%.2f%n", c.getSaldo()));
        }
    }

    private void inOrden() {
        txtResultado.setText("Recorrido in-orden (ordenado por número de cuenta):\n\n");
        txtResultado.append(String.format("%-15s %-25s %12s%n",
                "NÚMERO", "TITULAR", "SALDO"));
        txtResultado.append("----------------------------------------------------------\n");
        for (CuentaBancaria c : banco.inOrden()) {
            txtResultado.append(String.format("%-15s %-25s %12.2f%n",
                    c.getNumeroCuenta(), c.getTitular(), c.getSaldo()));
        }
    }
}
