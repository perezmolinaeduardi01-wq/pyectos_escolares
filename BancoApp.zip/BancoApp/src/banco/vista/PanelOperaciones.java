﻿package banco.vista;

import banco.Banco;
import banco.modelo.CuentaBancaria;

import javax.swing.*;
import java.awt.*;

public class PanelOperaciones extends JPanel {

    private final Banco banco;
    private final JTextField txtNumero = new JTextField(15);
    private final JTextField txtMonto  = new JTextField(15);

    public PanelOperaciones(Banco banco) {
        this.banco = banco;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Número de Cuenta:"), gbc);
        gbc.gridx = 1; add(txtNumero, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Monto:"), gbc);
        gbc.gridx = 1; add(txtMonto, gbc);

        JButton btnDepositar = new JButton("Depositar");
        JButton btnRetirar   = new JButton("Retirar");

        btnDepositar.addActionListener(e -> depositar());
        btnRetirar.addActionListener(e -> retirar());

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(btnDepositar, gbc);
        gbc.gridy = 3; add(btnRetirar, gbc);
    }

    private CuentaBancaria obtener() {
        CuentaBancaria c = banco.buscar(txtNumero.getText().trim());
        if (c == null) {
            JOptionPane.showMessageDialog(this, "Cuenta no encontrada");
        }
        return c;
    }

    private void depositar() {
        try {
            CuentaBancaria c = obtener();
            if (c == null) return;
            double monto = Double.parseDouble(txtMonto.getText());
            c.depositar(monto);
            banco.actualizarCuenta(c);
            JOptionPane.showMessageDialog(this, "Depósito exitoso. Nuevo saldo: $" + c.getSaldo());
            banco.actualizarTabla();
            txtMonto.setText("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void retirar() {
        try {
            CuentaBancaria c = obtener();
            if (c == null) return;
            double monto = Double.parseDouble(txtMonto.getText());
            if (c.retirar(monto)) {
                banco.actualizarCuenta(c);
                JOptionPane.showMessageDialog(this, "Retiro exitoso. Nuevo saldo: $" + c.getSaldo());
                banco.actualizarTabla();
                txtMonto.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Saldo insuficiente");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
