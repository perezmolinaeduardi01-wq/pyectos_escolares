﻿package banco.vista;

import banco.Banco;
import banco.modelo.CuentaBancaria;

import javax.swing.*;
import java.awt.*;

public class PanelGestion extends JPanel {

    private final Banco banco;
    private final JTextField txtTitular      = new JTextField(15);
    private final JTextField txtNumeroCuenta = new JTextField(15);
    private final JTextField txtMonto        = new JTextField(15);

    public PanelGestion(Banco banco) {
        this.banco = banco;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Titular:"), gbc);
        gbc.gridx = 1; add(txtTitular, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Número de Cuenta:"), gbc);
        gbc.gridx = 1; add(txtNumeroCuenta, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Saldo Inicial:"), gbc);
        gbc.gridx = 1; add(txtMonto, gbc);

        JButton btnAgregar    = new JButton("Agregar Cuenta");
        JButton btnEliminar   = new JButton("Eliminar Cuenta Seleccionada");
        JButton btnActualizar = new JButton("Actualizar Lista");
        JButton btnExportar   = new JButton("Exportar a XML");
        JButton btnImportar   = new JButton("Importar desde XML");
        JButton btnVaciar     = new JButton("Vaciar Todo (Árbol + XML)");

        btnAgregar.addActionListener(e -> agregar());
        btnEliminar.addActionListener(e -> eliminar());
        btnActualizar.addActionListener(e -> banco.actualizarTabla());
        btnExportar.addActionListener(e -> exportar());
        btnImportar.addActionListener(e -> importar());
        btnVaciar.addActionListener(e -> vaciar());

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(btnAgregar, gbc);
        gbc.gridy = 4; add(btnEliminar, gbc);
        gbc.gridy = 5; add(btnActualizar, gbc);
        gbc.gridy = 6; add(btnExportar, gbc);
        gbc.gridy = 7; add(btnImportar, gbc);
        gbc.gridy = 8; add(btnVaciar, gbc);
    }

    private void agregar() {
        try {
            String titular = txtTitular.getText().trim();
            String numero  = txtNumeroCuenta.getText().trim();
            double saldo   = Double.parseDouble(txtMonto.getText().trim());

            if (titular.isEmpty() || numero.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios");
                return;
            }
            if (banco.buscar(numero) != null) {
                JOptionPane.showMessageDialog(this, "Ya existe una cuenta con ese número");
                return;
            }
            banco.agregarCuenta(new CuentaBancaria(titular, numero, saldo));
            JOptionPane.showMessageDialog(this, "Cuenta agregada exitosamente");
            txtTitular.setText(""); txtNumeroCuenta.setText(""); txtMonto.setText("");
            banco.actualizarTabla();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El saldo debe ser un número válido");
        }
    }

    private void eliminar() {
        int fila = banco.getTabla().getSelectedRow();
        if (fila >= 0) {
            String numero = (String) banco.getModeloTabla().getValueAt(fila, 1);
            if (banco.eliminarCuenta(numero)) {
                banco.actualizarTabla();
                JOptionPane.showMessageDialog(this, "Cuenta eliminada exitosamente");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar la cuenta");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione una cuenta para eliminar");
        }
    }

    private void exportar() {
        try {
            banco.exportarXML();
            JOptionPane.showMessageDialog(this, "Exportado a: " + banco.getRutaXML());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al exportar: " + ex.getMessage());
        }
    }

    private void importar() {
        try {
            int n = banco.importarXML();
            JOptionPane.showMessageDialog(this, "Importadas " + n + " cuentas nuevas");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al importar: " + ex.getMessage());
        }
    }

    private void vaciar() {
        int r = JOptionPane.showConfirmDialog(this,
                "¿Eliminar TODAS las cuentas del árbol?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            banco.vaciarTodo();
            banco.actualizarTabla();
            JOptionPane.showMessageDialog(this, "Árbol vaciado");
        }
    }
}
