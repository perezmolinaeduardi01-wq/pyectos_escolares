﻿package banco.modelo;

public class CuentaBancaria {
    private String titular;
    private String numeroCuenta;
    private double saldo;

    public CuentaBancaria(String titular, String numeroCuenta, double saldoInicial) {
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
    }

    public String getTitular()      { return titular; }
    public String getNumeroCuenta() { return numeroCuenta; }
    public double getSaldo()        { return saldo; }

    public void setTitular(String titular){ this.titular = titular; }
    public void setSaldo(double saldo){ this.saldo = saldo; }

    public void depositar(double monto){
        if (monto > 0) saldo += monto;
    }

    public boolean retirar(double monto){
        if (monto > 0 && monto <= saldo){
            saldo -= monto;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return String.format("%s | %s | $%.2f", titular, numeroCuenta, saldo);
    }
}
