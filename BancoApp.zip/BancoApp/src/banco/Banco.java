﻿package banco;

import banco.estructuras.ArbolBinarioBusqueda;
import banco.modelo.CuentaBancaria;
import banco.persistencia.CuentaXMLManager;
import banco.vista.PanelBusqueda;
import banco.vista.PanelGestion;
import banco.vista.PanelOperaciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Banco extends JFrame {

    private final ArbolBinarioBusqueda arbol = new ArbolBinarioBusqueda();

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel lblSaldo;

    public Banco() {
        initGUI();
        actualizarTabla();

        setTitle("Sistema Bancario — BST en Memoria Externa + XML");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                arbol.cerrar();
            }
        });
    }

    private void initGUI() {
        setLayout(new BorderLayout(10, 10));

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Gestión de Cuentas",     new PanelGestion(this));
        tabbedPane.addTab("Operaciones Bancarias",  new PanelOperaciones(this));
        tabbedPane.addTab("Buscar Cuenta (BST)",    new PanelBusqueda(this));
        add(tabbedPane, BorderLayout.CENTER);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBorder(BorderFactory.createTitledBorder(
                "Lista de Cuentas (recorrido in-orden del árbol)"));

        String[] columnas = {"Titular", "Número de Cuenta", "Saldo"};
        tableModel = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        panelTabla.add(new JScrollPane(table), BorderLayout.CENTER);
        panelTabla.setPreferredSize(new Dimension(880, 220));
        add(panelTabla, BorderLayout.SOUTH);

        JPanel panelStats = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        lblSaldo = new JLabel("Total de cuentas: 0 | Saldo total: $0.00");
        panelStats.add(lblSaldo);
        add(panelStats, BorderLayout.NORTH);
    }

    // API pública 

    public JTable getTabla(){ return table; }
    public DefaultTableModel getModeloTabla(){ return tableModel; }

    /** Inserta una cuenta en el árbol en disco. */
    public void agregarCuenta(CuentaBancaria c) {
        arbol.insertar(c);
    }

    /** Elimina la cuenta del árbol en disco. */
    public boolean eliminarCuenta(String numeroCuenta) {
        return arbol.eliminar(numeroCuenta);
    }

    /** Busca una cuenta por número de cuenta. */
    public CuentaBancaria buscar(String numeroCuenta) {
        return arbol.buscar(numeroCuenta);
    }

    /** Actualiza los datos de una cuenta existente (por ejemplo, tras un depósito). */
    public void actualizarCuenta(CuentaBancaria c) {
        arbol.insertar(c); // insertar sobre clave existente = actualizar
    }

    /** Devuelve todas las cuentas ordenadas por número (recorrido in-orden). */
    public List<CuentaBancaria> inOrden() {
        return arbol.inOrden();
    }

    // XML

    public void exportarXML() throws Exception {
        CuentaXMLManager.exportar(arbol.inOrden());
    }

    /** Importa desde XML y devuelve el número de cuentas nuevas insertadas. */
    public int importarXML() throws Exception {
        List<CuentaBancaria> importadas = CuentaXMLManager.importar();
        int nuevas = 0;
        for (CuentaBancaria c : importadas) {
            if (arbol.buscar(c.getNumeroCuenta()) == null) {
                arbol.insertar(c);
                nuevas++;
            }
        }
        actualizarTabla();
        return nuevas;
    }

    public String getRutaXML() {
        return CuentaXMLManager.getRuta();
    }

    public void vaciarTodo() {
        arbol.vaciar();
    }

    // Tabla 

    public void actualizarTabla() {
        tableModel.setRowCount(0);
        double saldoTotal = 0;
        int total = 0;

        for (CuentaBancaria cuenta : arbol.inOrden()) {
            tableModel.addRow(new Object[]{
                    cuenta.getTitular(),
                    cuenta.getNumeroCuenta(),
                    String.format("$%.2f", cuenta.getSaldo())
            });
            saldoTotal += cuenta.getSaldo();
            total++;
        }

        lblSaldo.setText(String.format(
                "Total de cuentas: %d | Saldo total: $%.2f", total, saldoTotal));
    }

    //main

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Banco().setVisible(true));
    }
}
